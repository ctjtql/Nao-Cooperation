#coding: utf-8

from configureNao import ConfigureNao
from naoqi import ALProxy
import sys
import os
#sys.path.append("/home/meringue/Softwares/pynaoqi-sdk/") #naoqi directory
sys.path.append("./")
import numpy as np
import vision_definitions as vd
import time
import cv2

class Visual(ConfigureNao):
    """"
    a basis class for vision tast
    """

    def __init__(self, IP, PORT=9559, cameraId=vd.kBottomCamera, resolution=vd.kVGA):
        """
        Args:
            IP: NAO's IP
            cameraId: bottom camera (1,default) or top camera (0).
            resolution: kVGA, default: 640*480)
        Return:
            none
        """
        super(Visual, self).__init__(IP, PORT)
        self.cameraID = cameraId
        self.cameraName = "CameraBottom" if self.cameraId == vd.kBottomCamera else "CameraTop"
        self.resolution = resolution
        self.colorSpace = vd.kBGRColorSpace
        self.fps = 20

        self.frameHeight = 320
        self.frameWidth = 640
        self.frameChannels = 0
        self.frameArray = None

        self.cameraPitchRange = 47.64 / 180 * np.pi
        self.cameraYawRange = 60.97 / 180 * np.pi

    def updateframe(self, client="PC"):
        """
        get a new image from the specified camera and save it in self._frame.
        """
        if self.cameraProxy.getActiveCamera() != self.cameraID:
            self.cameraProxy.setActiveCamera(self.cameraID)
            time.sleep(1)
        videoClient = self.cameraProxy.subscribe(client, self.resolution, self.colorSpace, self.fps)
        frame = self.cameraProxy.getImageRemote(videoClient)
        self.cameraProxy.unsubscribe(videoClient)

        try:
            self.frameWidth = frame[0]
            self.frameHeight = frame[1]
            self.frameChannels = frame[2]
            self.frameArray = np.frombuffer(frame[6], dtype=np.uint8).reshape([frame[1], frame[0], frame[2]])
        except IndexError:
            print("get image failed!")

        if self.frameArray is None:
            print("no frame find")
            return np.array([])

        return self.frameArray

    def showFrame(self):
        """
        show current frame image and save it.
        """
        if self.frameArray is None:
            print("please get an image from Nao with the method updateFrame()")
        else:
            cv2.imshow("current frame", self.frameArray)
            cv2.waitKey(time)
            cv2.imwrite(imagepath, self.frameArray)
            print("current frame image has been saved in", imagepath)
