from naoqi import ALProxy


class (object):
    def __init__(self, IP="", PORT=9559):
        self.IP = IP
        self.PORT = PORT

        self.cameraProxy = ALProxy("ALVideoDevice", self.IP, self.PORT)

        self.motionProxy = ALProxy("ALMotion", self.IP, self.PORT)
        self.postureProxy = ALProxy("ALRobotPosture", self.IP, self.PORT)
